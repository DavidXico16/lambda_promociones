// handlers/getDispersionDescuentoHandler.js
const { Client } = require('pg');

const dbConfig = {
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl: { rejectUnauthorized: false }
};

exports.handler = async (event) => {
  console.log('Get Dispersion Descuento handler - Event received:', JSON.stringify(event, null, 2));

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Amz-Date, Authorization, X-Api-Key, X-Amz-Security-Token'
  };

  // Preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: JSON.stringify({ message: 'CORS preflight' }) };
  }

  // Solo se permite POST (para recibir idFlujo en body)
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Método no permitido. Usa POST.' })
    };
  }

  // Parsear body
  let body;
  try {
    body = event.body ? JSON.parse(event.body) : event;
  } catch (error) {
    console.log("Error: ", error)
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Cuerpo JSON inválido' }) };
  }

  // Validar campo requerido idFlujo
  const requiredFields = ['idFlujo'];
  const missingFields = requiredFields.filter(f => !body[f]);
  if (missingFields.length > 0) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Campo requerido faltante', missing: missingFields })
    };
  }

  const client = new Client(dbConfig);

  try {
    await client.connect();

    const query = `
      SELECT 
        id_datos_dispercion_descuento,
        id_promociones_ttp,
        vigencia_de_aplicacion,
        pronto_pago,
        precio_lista,
        aplicacion_montos_frontera,
        aplicacion_montos_nacionales,
        planes,
        porcentaje_de_descuento,
        monto_de_descuento,
        mes_inicio,
        vigencia_en_meses,
        responsable_modificacion AS nombre_editor,
        ultima_modificacion AS fecha_mod
      FROM datos_dispercion_descuento
      WHERE id_promociones_ttp = $1
    `;

    const result = await client.query(query, [body.idFlujo]);

    if (result.rows.length === 0) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({
          message: `No se encontraron registros para idFlujo: ${body.idFlujo}`,
          data: {}
        })
      };
    }

    // Parsear el campo JSON planes si existe
    const data = result.rows[0];
    if (data.planes) {
      try {
        data.planes = JSON.parse(data.planes);
      } catch {
        console.warn('No se pudo parsear el campo planes como JSON');
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: 'Datos obtenidos exitosamente de datos_dispercion_descuento',
        data
      })
    };

  } catch (error) {
    console.error('Error en GET datos_dispercion_descuento:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Error interno del servidor',
        details: error.message
      })
    };
  } finally {
    await client.end();
  }
};
